export { default } from "./Square";
